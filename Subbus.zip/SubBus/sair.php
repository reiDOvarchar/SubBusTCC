<?php
session_start();
session_destroy();


?>
<script>
    localStorage.removeItem("confirmacao")
    localStorage.removeItem("email")
    localStorage.removeItem("imagem")
    localStorage.removeItem("nome")
    localStorage.removeItem("sub")


    window.location.href = "login.php";
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    <p id="teste"></p>
</body>
</html>