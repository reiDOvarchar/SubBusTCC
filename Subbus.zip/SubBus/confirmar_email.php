<?php
  if(!isset($_SESSION)){
    session_start();
  }
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link href="Style.css" rel="stylesheet" />

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>


</head>

<body>




  <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 3%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php"
          style="color: rgb(233, 0, 0); font-size: 20; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position: absolute;">Confirmar E-mail</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">


          <li class="nav-item" style="list-style-type: none;">

          </li>
        </ul>
        <form class="d-flex" role="search">

        </form>

        
      </div>
    </div>
  </nav>

  

  <!--<style>
    #div1 {
      font-size:48px;
    }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   
    
    <div id="div1" class="fa"></div>
    
    <script>
    function ratestar() {
      var a;
      a = document.getElementById("div1");
      a.innerHTML = "&#xf006;";
      setTimeout(function () {
          a.innerHTML = "&#xf123;";
        }, 1000);
      setTimeout(function () {
          a.innerHTML = "&#xf005;";
        }, 2000);
    }
    ratestar();
    setInterval(ratestar, 3000);
    </script>-->


  
  <center>
    <h4>Confirme seu endereço de E-mail, clicando no link abaixo</h4>
    <h5><a href="#">Clique aqui</a></h5>
    <footer class = "footer-fixo">
      <div class="rodape">
    <li style="list-style-type: none;">
        
      <li style="list-style-type: none; margin-top: 0%;"><a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.php">Sobre nós</a></li>
    
        <p style="color: white; font-size: 10;">
          SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
          transporte público de Londrina
          <br>
          2022
        </p>
      </li>
      <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;" href="equipe.php">Equipe de desenvolvedores</a>
        
      </div>
    
    </footer>
  </center>
</body>




</html>