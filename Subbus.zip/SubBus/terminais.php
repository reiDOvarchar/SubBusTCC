<?php
if(!isset($_SESSION['nome'])){
  session_start();
}
include('cadastro_conexao.php');



?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet"/>

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>
 

</head>

<body>




  <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php" style="color: rgb(233, 0, 0); font-size: 20; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position:absolute;">Terminais</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          
          
          <li class="nav-item" style = "list-style-type: none;">
            
          </li>
        </ul>
        <form class="d-flex" role="search">
         
        </form>

        <div class="div-mensagem-usuario">
        <p class="mensagem-usuario">
          <?php 
          
        if(isset($_SESSION['nome'])){
          if(!isset($_SESSION['sub'])){
            echo '
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                if(localStorage.getItem("bencao") == null){
                notify.info({ message: "Seja bem vindo ' . $_SESSION['nome'] . '", timeout: 5000, noIcon: true })
                  localStorage.setItem("bencao","true")
              }
  
                
              });
            </script>
            ';
          }
          else if(isset($_SESSION['sub'])){
            echo '
            <script>
            let regex =/(?=")[^.]+/gim;
            var nome  = localStorage.getItem("nome")
            //nome.length = nome.length
            
            
              document.addEventListener("DOMContentLoaded", () => {
                if(localStorage.getItem("bencao") == null){
                notify.info({ message: "Seja bem vindo "+ nome, timeout: 5000, noIcon: true })
                  localStorage.setItem("bencao","true")
              }
  
                
              });
            </script>
            ';
          }

        }
        else if(!isset($_SESSION['nome'])){
          
        }
        ?>
        </p>
      </div>
      <?php
      if(isset($_SESSION)){
        echo '';
      }
      ?>
      <?php
      if(isset($_SESSION['nome'])){
        echo '<div class="dropdown" style="height: 40px;width: 4%;left:16.66%">
        <figure id=imagem>
          <div class="dropbtn" style="border:none; margin-top: -20%;" type="submit">';
      }
      
          ?>
            <?php
      if(isset($_SESSION['nome'])){
        if(!isset($_SESSION['sub'])){
          echo '<img class="img1" src = "imagens/usuario.png" style = "height: 40px; width: 40px;" id="img1"/>';
        }
        else{
          echo '<img id = "foto" style = "height:42.5px ; width:42.5px ; border-radius:50%"/>';
        }
      }
      else{

      }
      
      
      ?>

            <body>
              <?php
              if(isset($_SESSION['nome'])){
                echo '<script>
                const foto = localStorage.getItem("imagem")

                //document.ElementById()
                imagem.setAttribute("src", localStorage.imagem)
                //imagem.setAttribute("src" ,localStorage.imagem)
                setTimeout(() => {
                  document.getElementById("foto").src = localStorage.imagem
                }, 500);
              </script>
              <!--<img class="img2" src = "imagens/usuario_branco.png" style = "height: 40px; width: 40px; position: fixed; left: 97.05%" id=img2/>-->


          </div>

          <ul class="dropdown-content" style="left: -190%;">
            <center>

              <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a href="historico.php"
                  class=letra-menu id="letra-nao-mudar"><b>Histórico</a></b></li>
              <li class="divisor-menu" style="list-style-type: none;"></li>
              <li id="menu-rotas" class="item-menu" style="color: white;list-style-type: none;"><a href="conta.php"
                  class=letra-menu id="letra-nao-mudar" style="width:131.5%"><b style="margin-left:13%">Conta</a></b>
              </li>
              <li class="divisor-menu" style="list-style-type: none;"></li>
              <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a class=letra-menu
                  id="letra-nao-mudar" onclick=Sair()><b>Sair
                    <script>
                      function Sair() {
                        console.log("deu certo");
                        window.location.replace("sair.php");
                        localStorage.clear()
                      }
                    </script>

                </a></b></li>
            </center>
          </ul>
        </figure>
        </div>';
              
              }
              else{
                echo '<button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php"
                style="color: white; text-decoration: none;"><b>Entrar</b></a></button>
            <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a href="cadastro.php"
                style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a></button>';
              }
              
        ?>

      </div>
    </div>
  </nav>
   
<b>
            <div class="dropdown">
          
              <div class = "dropbtn" style="border:none"type = "submit">Menu
                <scan id = "triangle-right">
          
                </scan>
              </div>
              
              
              <ul class="dropdown-content">
              
                <center>
                <li id="menu-linhas" class = "item-menu" style="color: white;list-style-type: none"><a href="linha.php" class = letra-menu id = "letra-nao-mudar">Linhas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-rotas" class = "item-menu" style="color: white;list-style-type: none;"><a href="rotas.php" class = letra-menu id = "letra-nao-mudar">Rotas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-terminais" class = "item-menu" style="color: white;list-style-type: none;"><a href="terminais.php" class = letra-menu id = "letra-nao-mudar">Terminais</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-ajuda" class = "item-menu" style="color: white;list-style-type: none;"><a href = "ajuda.php" class = letra-menu id = "letra-nao-mudar">Ajuda</a></li>
                </center>
              </ul>
            </div>
          </b> 


 
  <center>
  
  <form method="POST" id="form-terminais" action="">
    <b><li class = "li-linha" style = "font-size: 32px; margin-bottom: 1.8%">Pesquise pelos terminais aqui:</li></b>
    <li style="list-style-type: none; margin-top: 0.9%;font-size: 20px"><b style="font-size: 10;">Terminais:
    <input id="pesquisa-terminais" name="buscaTerm"class="pesquisar-linha" placeholder="Pesquisar terminais, ex: Terminal Central" style="margin-left: 0.5%; margin-right: 1%;" aria-label="Search"></b>
    <button class="botao-pesquisar" type="submit" id="botao-pesquisar"><a href="#" style="color: white;text-decoration: none;"><b>Pesquisar</b></a></button></li>
    
      </form>

      <div style = "margin-top: 4.5%">
            <table class="table table-bordered border-light">
               <thead >
                  <tr >
                    
                     <h1> <th>Nome</th></h1>
                      <th>Endereço</th>
                      <th>Horario inicio</th>
                      <th>Horario Término</th>
                      <th>Telefone</th>
                  </tr>
               </thead>
               <tbody>
                  

                  <?php
                  if(!isset($_POST['buscaTerm'])){
                    ?>
                    <tr>
                        <td>Digite algo para pesquisar</td>
                    </tr>
                  <?php
                  } else {
                    $data = date('d/m/Y');
                      date_default_timezone_set('America/Sao_Paulo');
                      $hora = date('H:i:s'); 
                      $pesquisa = $mysqli -> real_escape_string($_POST['buscaTerm']);
                      $_SESSION['historico'] = $pesquisa;
                      $id = $_SESSION['id'];
                      $cont_for = 1;
                        
                        if(!empty($pesquisa)){
                          $sql_contador = "SELECT max(contador) FROM historico WHERE id = '$id';";
                          $result_contador = $mysqli->query($sql_contador);
                          $user_contador = $result_contador->fetch_array();
                          $contador = $user_contador['max(contador)'];
                          $sql_update = "UPDATE historico SET pesquisa = '$pesquisa', tipo = 'Terminais', data_momento = '$data', horario = '$hora', confirmacao = 1,
                          contador = '$contador' + 1, link = 'terminais.php'
                          WHERE id = '$id' AND (confirmacao IS NULL OR pesquisa IS NULL) LIMIT 1";
                          $result_update = $mysqli->query($sql_update);
                          
                          
                          $sql_cont_confirmacao = "SELECT count(confirmacao) FROM historico WHERE id = '$id' AND confirmacao = 1 ORDER BY id LIMIT 1;";
                          $result_cont_confirmacao = $mysqli->query($sql_cont_confirmacao);
                          
                          $user_data = $result_cont_confirmacao->fetch_array();
                          
                          $cont_confirmacao = $user_data['count(confirmacao)'];    
                          
                          $cont_for++;

                          if($cont_confirmacao == 20){
                            $sql_null = "UPDATE historico SET confirmacao = NULL
                            WHERE id = '$id'";
                            $result_null = $mysqli->query($sql_null);
                          }
                          
                        }

                    $pesquisa = $mysqli -> real_escape_string($_POST['buscaTerm']);
                    $sql_code = "SELECT * FROM terminais 
                    WHERE nome LIKE '%$pesquisa%'
                    OR endereco LIKE '%$pesquisa%' 
                    OR telefone LIKE '%$pesquisa%'
                    ORDER BY id ASC";

                    $sql_query = $mysqli->query($sql_code) or die ("ERRO ao consultar" . $mysqli->error);

                    if($sql_query ->num_rows == 0){
                      ?>
                     <tr>
                        <td colpsan="5">Nenhum resultado encontrado</td>
                     </tr>
                     <?php
                    } else{
                      while($dados = $sql_query ->fetch_assoc() ){
                        ?>
                        <tr >
                            <h2><th><?php echo $dados ['nome']; ?></th></h2>
                            <td><?php echo $dados ['endereco']; ?></td>
                            <td><?php echo $dados ['horario_inicio']; ?></td>
                            <td><?php echo $dados ['horario_termino']; ?></td>
                            <td><?php echo $dados ['telefone']; ?></td>
                        </tr>
                        <?php
                      }

                    }
                        ?>
                  <?php
                  } ?>
                </tbody>
            </table>
          </div>


    <footer class = "footer-fixo">
      <div class="rodape">
    <li style="list-style-type: none;">
        
      <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre nós</a>
      <li style="list-style-type: none; margin-top: 0%;"><a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre nós</a></li>
    
        <p style="color: white; font-size: 10;">
          SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
          transporte público de Londrina
          <br>
          2022
        </p>
      </li>
      <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;" href="equipe.php">Equipe de desenvolvedores</a>
        
      </div>
    
    </footer>
</center>
<script> </script>
</body>

  


</html>