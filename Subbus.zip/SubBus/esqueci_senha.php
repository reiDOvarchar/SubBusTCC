<?php
session_start();
ob_start();
include_once ('login_conexao.php');

require_once('src/PHPMailer.php');
require_once('src/SMTP.php');
require_once('src/Exception.php');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;  
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sub BuS</title>
    <link rel="stylesheet" href="imagem.css">
    <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

    <link href="Imagem.css">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet" />
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>

</head>
<body>
<nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
        <div class="container-fluid">
            <li style="list-style-type: none;"><a class="navbar-brand" href="index.php"
                    style="color: rgb(233, 0, 0); font-size: 32; margin-right: -23%;">SBS</a></li>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position:absolute;">Recuperar a senha
            </p>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">



                    <li class="nav-item" style="list-style-type: none;">

                    </li>
                </ul>
                <form class="d-flex" role="search">

                </form>


                <button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php"
                  style="color: white; text-decoration: none;"><b>Entrar</b></a></button>
                <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a href="cadastro.php"
                  style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a>
            </div>
        </div>
    </nav>

    <b>
        <div class="dropdown">

            <div class="dropbtn" style="border:none" type="submit">Menu
                <scan id="triangle-right">

                </scan>
            </div>


            <ul class="dropdown-content">
                <!--<li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="linha.html">Linhas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="rotas.html">Rotas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="terminais.html">Terminais<br></a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="ajuda.html">Ajuda</a></li>-->
                <center>
                    <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a
                            href="linha.php" class=letra-menu id="letra-nao-mudar">Linhas</a></li>
                    <li class="divisor-menu" style="list-style-type: none;"></li>
                    <li id="menu-rotas" class="item-menu" style="color: white;list-style-type: none;"><a
                            href="rotas.php" class=letra-menu id="letra-nao-mudar">Rotas</a></li>
                    <li class="divisor-menu" style="list-style-type: none;"></li>
                    <li id="menu-terminais" class="item-menu" style="color: white;list-style-type: none;"><a
                            href="terminais.php" class=letra-menu id="letra-nao-mudar">Terminais</a></li>
                    <li class="divisor-menu" style="list-style-type: none;"></li>
                    <li id="menu-ajuda" class="item-menu" style="color: white;list-style-type: none;"><a
                            href="ajuda.php" class=letra-menu id="letra-nao-mudar">Ajuda</a></li>
                </center>
            </ul>
        </div>
    </b>





    <center>
        <div style="position: absolute;margin-left: 11.9%;"><img src="imagens/TCC_Logo.png" height="450px"
                width="450px " />
            <div style="color: darkred;font-size: 30px;">
                SuB BuS
                <p style="font-size: 20px;">Sistema de rotas urbanas</p>
            </div>
        </div>
        <div style="width: 6px; height: 700px;background-color: black; border-radius: 6px;position: static;"></div>
        <form action="" method="POST">
            <scan class="div-login" style="margin-bottom: 0%">

            <form method = "POST" action="">
            <p style="color: white; margin-top:5%;font-size: 30px;">Recuperar a senha</p>
            <div style="height: 20px;color:white">
<?php
        
if(isset($_POST['ok'])){
  $confirm = true;
  $confirm2 = true;
  $email = $mysqli->escape_string($_POST['email']);

  $sql_code = "SELECT * FROM usuario WHERE email = '$email'";
  $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);  
  $quantidade = $sql_query -> num_rows;

  
      
  if($quantidade == 1){
      $usuario = $sql_query->fetch_assoc();
      if(!isset($_SESSION)){
        session_start($_SESSION['nome']);
        
      }
      $_SESSION_ID = $usuario['id'];
      $_SESSION['nome'] = $usuario['nome'];

  }
     
      
  if(empty($email)){
    echo "Preencha o campo abaixo com seu E-mail";
    $confirm = false;
    $confirm2 = false;
  }

  if(!filter_var($email, FILTER_VALIDATE_EMAIL) && $confirm2 == true){

    echo $erro[] = "E-mail inválido <br>";
    $confirm = false;
    
  }
  else if($quantidade == 0 && $confirm == true)
      echo $erro[] = "O e-mail informado não existe no banco de dados";

  if($quantidade > 0){
    
    $novasenha = substr(md5(time()), 0, 8);
  $nscriptografada = md5(md5($novasenha));
  
    

    $mail = new PHPMailer(true);
    
    try{
        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'eervi82@gmail.com';
        $mail->Password = 'hsaibrwihxssofon';
        //$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = '587';

        $mail->setFrom('eervi82@gmail.com');
        $mail->addAddress($email);
        $mail->isHTML(true);
        $mail->Subject = "Sua nova senha";
        $mail->Body = "Sua nova senha é: " . $novasenha;
        $mail->AltBody = "Sua nova senha é: " . $novasenha;

        if($mail->send()){
          echo "Email enviado com sucesso";
          $to = $email;
          $subject = "Sua nova senha";
          $message = "Sua nova senha é: " . $novasenha;
          $headers = "From: klapaucyus@gmail.com";
          $sql_code = "UPDATE usuario set senha = '$novasenha' WHERE
          email = '$email'";
          $sql_query = $mysqli->query($sql_code) or die($mysqli->error);
          $email = "japones";
        }
        else{
          echo "Email não enviado";
        }

    }
    catch(Exception $e){
      echo "Erro ao enviar mensagem: {$mail->ErrorInfo}";
    }
  }
  
}

?>
            </div>
    <li style="list-style-type: none;color:  white;">E-mail:<input class="campo-texto-pequeno-login"
    placeholder="Digite aqui" aria-label="Search" style="margin-right:1.5%;margin-top: 9%;" name="email"></li>
    <b><input class="botao-login-entrar" type="submit" style="margin-right: 1%;margin-top: 8%;font-weight:bold"
              id="login-entrar" name="ok" value="Enviar"></b>
              <div
                    style="width: 500px;height:4px;margin-top: 7%;z-index: 1;background-color: white;border-radius: 8px;">
                </div>
            <p style="margin-top: 7%;color: white">Uma mensagem contendo sua nova senha será enviada para<br>a Caixa de Entrada de seu endereço de E-mail</p>
            <p style="margin-top: 7%;color: white">Não esqueça de sempre checar seu Lixo Eletrônico,<br>pode ser que o E-mail seja enviado fora da Caixa de Entrada</p>

    </form>
                
            </scan>
        </form>



        <footer class = "footer-fixo">
            <div class="rodape">
                <li style="list-style-type: none;">

                    
                <li style="list-style-type: none; margin-top: 0%;"><a
                        style="color:white ; text-align: start;position: absolute; margin-left: -46%;"
                        href="sobre.php">Sobre
                        nós</a></li>

                <p style="color: white; font-size: 16 ;">
                    SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso
                    ao
                    transporte público de Londrina
                    <br>
                    2022
                </p>
                </li>
                <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;"
                    href="equipe.php">Equipe de desenvolvedores</a>

            </div>

        </footer>
    </center>


</body>
</html>