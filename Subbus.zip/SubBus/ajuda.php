<?php
if(!isset($_SESSION['nome'])){
  session_start();
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet"/>

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@1,100&display=swap" rel="stylesheet">
 

</head>

<body style="height: 1200px;">




  <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php" style="color: rgb(233, 0, 0); font-size: 20; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position:absolute;">Ajuda</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          
          
          <li class="nav-item" style = "list-style-type: none;">
            
          </li>
        </ul>
        <form class="d-flex" role="search">
         
        </form>

        <div class="div-mensagem-usuario">
        <p class="mensagem-usuario">
          <?php 
          
        if(isset($_SESSION['nome'])){
          if(!isset($_SESSION['sub'])){
            echo '
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                if(localStorage.getItem("bencao") == null){
                notify.info({ message: "Seja bem vindo ' . $_SESSION['nome'] . '", timeout: 5000, noIcon: true })
                  localStorage.setItem("bencao","true")
              }
  
                
              });
            </script>
            ';
          }
          else if(isset($_SESSION['sub'])){
            echo '
            <script>
            let regex =/(?=")[^.]+/gim;
            var nome  = localStorage.getItem("nome")
            //nome.length = nome.length
            
            
              document.addEventListener("DOMContentLoaded", () => {
                if(localStorage.getItem("bencao") == null){
                notify.info({ message: "Seja bem vindo "+ nome, timeout: 5000, noIcon: true })
                  localStorage.setItem("bencao","true")
              }
  
                
              });
            </script>
            ';
          }

        }
        else if(!isset($_SESSION['nome'])){
          
        }
        ?>
        </p>
      </div>
      <?php
      if(isset($_SESSION)){
        echo '';
      }
      ?>
      <?php
      if(isset($_SESSION['nome'])){
        echo '<div class="dropdown" style="height: 40px;width: 4%;left:16.66%">
        <figure id=imagem>
          <div class="dropbtn" style="border:none; margin-top: -20%;" type="submit">';
      }
      
          ?>
            <?php
      if(isset($_SESSION['nome'])){
        if(!isset($_SESSION['sub'])){
          echo '<img class="img1" src = "imagens/usuario.png" style = "height: 40px; width: 40px;" id="img1"/>';
        }
        else{
          echo '<img id = "foto" style = "height:42.5px ; width:42.5px ; border-radius:50%"/>';
        }
      }
      else{

      }
      
      
      ?>

            <body>
              <?php
              if(isset($_SESSION['nome'])){
                echo '<script>
                const foto = localStorage.getItem("imagem")

                //document.ElementById()
                imagem.setAttribute("src", localStorage.imagem)
                //imagem.setAttribute("src" ,localStorage.imagem)
                setTimeout(() => {
                  document.getElementById("foto").src = localStorage.imagem
                }, 500);
              </script>
              <!--<img class="img2" src = "imagens/usuario_branco.png" style = "height: 40px; width: 40px; position: fixed; left: 97.05%" id=img2/>-->


          </div>

          <ul class="dropdown-content" style="left: -190%;">
            <center>

              <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a href="historico.php"
                  class=letra-menu id="letra-nao-mudar"><b>Histórico</a></b></li>
              <li class="divisor-menu" style="list-style-type: none;"></li>
              <li id="menu-rotas" class="item-menu" style="color: white;list-style-type: none;"><a href="conta.php"
                  class=letra-menu id="letra-nao-mudar" style="width:131.5%"><b style="margin-left:13%">Conta</a></b>
              </li>
              <li class="divisor-menu" style="list-style-type: none;"></li>
              <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a class=letra-menu
                  id="letra-nao-mudar" onclick=Sair()><b>Sair
                    <script>
                      function Sair() {
                        console.log("deu certo");
                        window.location.replace("sair.php");
                        localStorage.clear()
                      }
                    </script>

                </a></b></li>
            </center>
          </ul>
        </figure>
        </div>';
              
              }
              else{
                echo '<button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php"
                style="color: white; text-decoration: none;"><b>Entrar</b></a></button>
            <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a href="cadastro.php"
                style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a></button>';
              }
              
        ?>

      </div>
    </div>
  </nav>
   
<b>
            <div class="dropdown">
          
              <div class = "dropbtn" style="border:none"type = "submit">Menu
                <scan id = "triangle-right">
          
                </scan>
              </div>
              
              
              <ul class="dropdown-content">
                
                <center>
                <li id="menu-linhas" class = "item-menu" style="color: white;list-style-type: none"><a href="linha.php" class = letra-menu id = "letra-nao-mudar">Linhas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-rotas" class = "item-menu" style="color: white;list-style-type: none;"><a href="rotas.php" class = letra-menu id = "letra-nao-mudar">Rotas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-terminais" class = "item-menu" style="color: white;list-style-type: none;"><a href="terminais.php" class = letra-menu id = "letra-nao-mudar">Terminais</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-ajuda" class = "item-menu" style="color: white;list-style-type: none;"><a href = "ajuda.php" class = letra-menu id = "letra-nao-mudar">Ajuda</a></li>
                </center>
              </ul>
            </div>
          </b> 

          
          

        
    <center>

      
    <b>
      <p style="font-size:20px; color:black; font-family: Arial, Helvetica, sans-serif;">Bem vindo ao Menu de ajuda, como podemos ajudar ?</p>
    </b>
    
      <textarea class="pesquisar-ajuda" placeholder="Descreva seu problema aqui:" style="margin-left: 0.5%; margin-right: 1%; margin-top: 2%;" aria-label="Search"></textarea>
      <div style="margin-bottom: 4%;">
        <button class="botao-pesquisar" type="submit" id="botao-pesquisar"><a href="#"
            style="color: white;text-decoration: none;"><b>Enviar</b></a></button>
      </div>

      <b><div style="margin-top: 25px;"><p style="font-size: 27px;font-family:system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif">Perguntas Frequentes</p>
        
      
      </div></b>
      
      <div class='pergunta'>
  
        <input type='checkbox' id='pergunta-1' >
        <label for='pergunta-1' style="margin-top: 25px;"><p class = "fonte-pergunta">Porque o site foi criado ?</p></label>
        <div class='answer' style="color: grey;">
          <h5>
          o site foi criado para fins pedagógicos e com a intenção de informar as linhas de transporte coletivo.
          </h5>
        </div>
      </div>
      
      <div class='pergunta'>
        <input type='checkbox' id='pergunta-2'>
        <label for='pergunta-2'><p class = "fonte-pergunta">
          A inscrição é paga ?
        </p>
            
        </label>
        <div class='answer' style="color: grey;">
          <h5>
          o sistema é totalmente gratuito e a inscrição tem o intuito de fornecer ferramentas adicionais, protegendo a sua privacidade.
          </h5>
        </div>
      </div>

      <div class='pergunta'>
        <input type='checkbox' id='pergunta-3'>
        <label for='pergunta-3'><p class = "fonte-pergunta">
          Como voltar ao Menu principal ?
        </p>
            
        </label>
        <div class='answer' style="color: grey;">
          <h5>
          Todas as páginas possuem o símbolo SBS, que ao clicar, ele redireciona para o menu.
          </h5>
        </div>
      </div>

      <div class='pergunta'>
        <input type='checkbox' id='pergunta-4'>
        <label for='pergunta-4'><p class = "fonte-pergunta">
          Como funciona a pesquisa no site ?
        </p>
            
        </label>
        <div class='answer' style="color: grey;">
          <h5>
        Ao digitar a linha, rota ou terminal desejado clique no botão pesquisar para ir para a área desejada.
          </h5>
        </div>
      </div>
    

      <footer class = "footer-fixo">
        <div class="rodape">
      <li style="list-style-type: none;">
          
        <li style="list-style-type: none; margin-top: 0%;"><a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.php">Sobre nós</a></li>
      
          <p style="color: white; font-size: 10;">
            SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
            transporte público de Londrina
            <br>
            2022
          </p>
        </li>
        <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;" href="equipe.php">Equipe de desenvolvedores</a>
          
        </div>
      
      </footer>
  
</center>

</body>

  


</html>