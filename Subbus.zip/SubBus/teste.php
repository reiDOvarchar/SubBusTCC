<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <title>Document</title>
</head>
<body>
    
    <script>
        /*var nome  = localStorage.getItem("nome")
        localStorage.getItem("imagem")
        var imagem = localStorage.getItem("imagem")

        function formatar(){
            
           
        }
        function mudar(){
                document.getElementById("mudarTexto").style.backgroundColor = "blue";
                console.log("gostosa");
            }*/

    </script>
    

<script>
  /*function mudarJSparaPHP(nome, valor, dias){
     // Creating a cookie after the document is ready
  $(document).ready(function () {
      createCookie(nome, valor, dias);
  });
     
  // Function to create the cookie
  function createCookie(name, value, days) {
      var expires;
        
      if (days) {
          var date = new Date();
          date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
          expires = "; expires=" + date.toGMTString();
      }
      else {
          expires = "";
      }
        
      document.cookie = escape(name) + "=" + 
          escape(value) + expires + "; path=/";
    }
  }
   
  mudarJSparaPHP("nome", localStorage.nome, "10")*/

  var variaveljs = localStorage.nome;
    
  </script>

<?php
    //sleep(3);
    //$valor = $_COOKIE["gfg"];
    //var_dump($_SESSION['nome']);
    
    $variavelphp = "<script>document.write(variaveljs)</script>";
    echo $variavelphp;
  
    

?>

    <p ></p>
</body>
</html>