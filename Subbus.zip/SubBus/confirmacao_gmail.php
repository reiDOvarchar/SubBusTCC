<?php
    if(!isset($_SESSION)){
        session_start();
    }

    include_once("cadastro_conexao.php");
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <title>Confirmação de Gmail</title>
    <script>
    

    
    </script>
</head>
<body >
    <?php

    $nome = $_COOKIE["nome"];
    
    $email = $_COOKIE["email"];
    
    $sub = $_COOKIE["sub"];
    
    

    $_SESSION['email'] = $email;
    $_SESSION['nome'] = $nome;
    $_SESSION['sub'] = $sub;

    

    $erro = false;
   $result_usuario = "SELECT id FROM usuario WHERE email='$email'";
   $resultado_usuario = mysqli_query($mysqli,$result_usuario);
   
   
   if(($resultado_usuario) AND ($resultado_usuario->num_rows != 0)){
       echo  $erro = true.'<br>';
     }
    else{
        echo "Tudo certo colega";
    }

    if(!$erro){
        $sql = "INSERT INTO usuario (nome, senha, email, sub) VALUES ('$nome', NULL, '$email', '$sub');";
        $result_sql = $mysqli->query($sql);
        $cont = 0;
        $sql_id = "SELECT id FROM usuario WHERE email = '$email';";
        $result_id = $mysqli->query($sql_id);
        $user_data = $result_id->fetch_array();
        $id = $user_data['id'];
        $_SESSION['id'] = $id;
        echo '<br>'.$id;
        do{
            $query_update_table = "INSERT INTO  historico (id, contador) VALUES ($id, 0)";
            $result = mysqli_query($mysqli,$query_update_table);
            $cont++;
          }while($cont != 20);
        if (!mysqli_query($mysqli, $sql)) {
            echo "Error: " . $sql . "<br>";
        } 
        $erro = true;
        $sql_delete = "DELETE usuario FROM usuario WHERE id = '$id'+1;";
        $result_delete = $mysqli->query($sql_delete);
    }
    $sql_id = "SELECT id FROM usuario WHERE sub = '$sub';";
    $result_id = $mysqli->query($sql_id);
    $user_data = $result_id->fetch_array();
    $id = $user_data['id'];
    $_SESSION['id'] = $id;

    

    //header("location: index.php");
    ?>
    <form method = "GET" action=""></form>
    <script>
        window.location.href = "index.php";
    </script>
</body>
</html>