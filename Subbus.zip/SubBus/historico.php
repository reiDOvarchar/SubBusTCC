<?php
session_start();
if(!isset($_SESSION['nome'])){
    header("location: index.php");
}

include_once ("login_conexao.php");
?>
<!DOCTYPE html>
<html lang="pt-br" style="padding-bottom: 0%;">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet"/>

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>
  

 

</head>

<body>




  <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php" style="color: rgb(233, 0, 0); font-size: 20; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px; position:absolute;">Histórico</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">

          
          
          <li class="nav-item" style = "list-style-type: none;">
            
          </li>
        </ul>
        <form class="d-flex" role="search">
         
        </form>

        <div class="div-mensagem-usuario">
        <p class="mensagem-usuario">
          <?php 
          
        if(isset($_SESSION['nome'])){
          if(!isset($_SESSION['sub'])){
            echo '
            <script>
              document.addEventListener("DOMContentLoaded", () => {
                if(localStorage.getItem("bencao") == null){
                notify.info({ message: "Seja bem vindo ' . $_SESSION['nome'] . '", timeout: 5000, noIcon: true })
                  localStorage.setItem("bencao","true")
              }
  
                
              });
            </script>
            ';
          }
          else if(isset($_SESSION['sub'])){
            echo '
            <script>
            let regex =/(?=")[^.]+/gim;
            var nome  = localStorage.getItem("nome")
            //nome.length = nome.length
            
            
              document.addEventListener("DOMContentLoaded", () => {
                if(localStorage.getItem("bencao") == null){
                notify.info({ message: "Seja bem vindo "+ nome, timeout: 5000, noIcon: true })
                  localStorage.setItem("bencao","true")
              }
  
                
              });
            </script>
            ';
          }

        }
        else if(!isset($_SESSION['nome'])){
          
        }
        ?>
        </p>
      </div>
      <?php
      if(isset($_SESSION)){
        echo '';
      }
      ?>
      <?php
      if(isset($_SESSION['nome'])){
        echo '<div class="dropdown" style="height: 40px;width: 4%;left:16.66%">
        <figure id=imagem>
          <div class="dropbtn" style="border:none; margin-top: -20%;" type="submit">';
      }
      
          ?>
            <?php
      if(isset($_SESSION['nome'])){
        if(!isset($_SESSION['sub'])){
          echo '<img class="img1" src = "imagens/usuario.png" style = "height: 40px; width: 40px;" id="img1"/>';
        }
        else{
          echo '<img id = "foto" style = "height:42.5px ; width:42.5px ; border-radius:50%"/>';
        }
      }
      else{

      }
      
      
      ?>

            <body>
              <?php
              if(isset($_SESSION['nome'])){
                echo '<script>
                const foto = localStorage.getItem("imagem")

                //document.ElementById()
                imagem.setAttribute("src", localStorage.imagem)
                //imagem.setAttribute("src" ,localStorage.imagem)
                setTimeout(() => {
                  document.getElementById("foto").src = localStorage.imagem
                }, 500);
              </script>
              <!--<img class="img2" src = "imagens/usuario_branco.png" style = "height: 40px; width: 40px; position: fixed; left: 97.05%" id=img2/>-->


          </div>

          <ul class="dropdown-content" style="left: -190%;">
            <center>

              <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a href="historico.php"
                  class=letra-menu id="letra-nao-mudar"><b>Histórico</a></b></li>
              <li class="divisor-menu" style="list-style-type: none;"></li>
              <li id="menu-rotas" class="item-menu" style="color: white;list-style-type: none;"><a href="conta.php"
                  class=letra-menu id="letra-nao-mudar" style="width:131.5%"><b style="margin-left:13%">Conta</a></b>
              </li>
              <li class="divisor-menu" style="list-style-type: none;"></li>
              <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a class=letra-menu
                  id="letra-nao-mudar" onclick=Sair()><b>Sair
                    <script>
                      function Sair() {
                        console.log("deu certo");
                        window.location.replace("sair.php");
                        localStorage.clear()
                      }
                    </script>

                </a></b></li>
            </center>
          </ul>
        </figure>
        </div>';
              
              }
              else{
                echo '<button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php"
                style="color: white; text-decoration: none;"><b>Entrar</b></a></button>
            <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a href="cadastro.php"
                style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a></button>';
              }
              
        ?>

      </div>
    </div>
  </nav>
   
<b>
            <div class="dropdown">
          
              <div class = "dropbtn" style="border:none"type = "submit">Menu
                <scan id = "triangle-right">
          
                </scan>
              </div>
              
              
              <ul class="dropdown-content">
               
                <center>
                <li id="menu-linhas" class = "item-menu" style="color: white;list-style-type: none"><a href="linha.php" class = letra-menu id = "letra-nao-mudar">Linhas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-rotas" class = "item-menu" style="color: white;list-style-type: none;"><a href="rotas.php" class = letra-menu id = "letra-nao-mudar">Rotas</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-terminais" class = "item-menu" style="color: white;list-style-type: none;"><a href="terminais.php" class = letra-menu id = "letra-nao-mudar">Terminais</a></li>
                <li class = "divisor-menu" style="list-style-type: none;"></li>
                <li id="menu-ajuda" class = "item-menu" style="color: white;list-style-type: none;"><a href = "ajuda.php" class = letra-menu id = "letra-nao-mudar">Ajuda</a></li>
                </center>
              </ul>
            </div>
          </b> 



  
 
    
    <center>
      <div>
        <table class="table table-bordered border-light" width="75%" style = "margin: 3%; margin-right: 5%;width:80%;margin-bottom:8%">
          <thead>
            <tr>
              <th>Pesquisa</th>
              <th>Página</th>
              <th>Data de pesquisa</th>
              <th>Horário</th>
              <th>Link</th>
            </tr>
          </thead>
          <tbody>
            <?php
                     
                        ?>
            <tr>
              
            </tr>
            <?php
                        $id = $_SESSION['id']; 
                        
                        $sql_code = "SELECT * FROM historico 
                        WHERE id = '$id'
                        ORDER BY contador DESC";
  
                        $sql_query = $mysqli->query($sql_code) or die ("ERRO ao consultar" . $mysqli->error);
  
                        if($sql_query ->num_rows == 0){
                          ?>
            <tr>
              <td colpsan="7">Nenhum resultado pesquisado</td>
            </tr>
            <?php
                        } else{
                          while($dado = $sql_query ->fetch_assoc() ){
                            ?>
            <tr>
              <th><?php echo $dado ['pesquisa']; ?></th>
              <td><?php echo $dado ['tipo']; ?></td>
              <td><?php echo $dado ['data_momento']; ?></td>
              <td><?php echo $dado ['horario']; ?></td>
              <?php
              if(isset($dado['link'])){
                echo '
                <td ><button class="botao-pesquisar" type="submit" id="botao-pesquisar" style="margin-left: 0%;"><a href="'. $dado ['link'] . '"style="color: white;text-decoration: none;"><b>Ir para</b></a></button></li></b></td>

                ';
              }
              
              ?>
              </tr>
            <?php
                          }
  
                        }
                            ?>
            <?php
                       ?>
          </tbody>
        </table>
      </div>
  </center>
  
    
   <center>
    <footer class ="footer-fixo">
      <div class="rodape">
    <li style="list-style-type: none;">
        
      <li style="list-style-type: none; margin-top: 0%;"><a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.php">Sobre nós</a></li>
    
        <p style="color: white; font-size: 10;">
          SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
          transporte público de Londrina
          <br>
          2022
        </p>
      </li>
      <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;" href="equipe.php">Equipe de desenvolvedores</a>
        
      </div>
    
    </footer>
</center>
<Script src="Animacao.js"></Script>
</body>

  


</html>