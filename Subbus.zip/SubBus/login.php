<?php

  session_start();
  
  include('login_conexao.php');
  if(/*isset($_POST['nome']) || */isset($_POST['email']) || isset($_POST['senha'])){
    /*if(strlen($_POST['nome']) == 0){
      echo "Preencha seu nome";
    }*/
    if(strlen($_POST['email']) == 0){
      
    }
    else if(strlen($_POST['senha']) == 0){
      
    }
    
    else{
      /*$ct_nome = $mysqli->real_escape_string($_POST['nome']);*/
      $email = $mysqli->real_escape_string($_POST['email']);
      $senha = $mysqli->real_escape_string($_POST['senha']);
      
      $sql_code = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
      $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);

      $quantidade = $sql_query -> num_rows;
      if($quantidade == 1){
          $usuario = $sql_query->fetch_assoc();
          if(!isset($_SESSION)){
            session_start($_SESSION['nome']);
            
          }
            $_SESSION_ID = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['email'] = $usuario['email'];
            $email = $usuario['email'];
            $sql_id = "SELECT id FROM usuario WHERE email = '$email';";
            $result_id = $mysqli->query($sql_id);
            $user_data = $result_id->fetch_array();
            $id = $user_data['id'];
            $_SESSION['id'] = $id;
            //echo '<a href="index.php">aaa</a>';
            sleep(2);
            header("Location: index.php");
          
          
      }
      
      else{
          
        
      }
    }
  }
  ?></p>
<!DOCTYPE html>
<html lang="pt-br">

<script src="https://accounts.google.com/gsi/client" asyn defer></script>
<script src="https://unpkg.com/jwt-decode/build/jwt-decode.js"></script>
<script src="Animacao.js" defer></script>
<script>
    function handleCredentialResponse(response) {
    const data = jwt_decode(response.credential)
    console.log(data)

    //document.getElementById("nome").textContent = data.name;
    //document.getElementById("sub").textContent = data.sub
    //document.getElementById("given_name").textContent = data.given_name
    //document.getElementById("family_name").textContent = data.family_name
    //document.getElementById("email").textContent = data.email
    //document.getElementById("verifiedEmail").textContent = data.email_verified
    imagem.setAttribute("src" ,localStorage.imagem)
    if(data.email_verified == true){
        
        localStorage.setItem("confirmacao",true)

        //window.location.href = "index_usuario.php";
        window.location.href = "confirmacao_gmail.php";
    }
    //localStorage.setItem('google',JSON.stringify(data.pictue))
    //localStorage.getItem('google',JSON.stringify(data.pictue))
    localStorage.imagem = (data.picture)
    localStorage.nome = (data.name)
    localStorage.email = (data.email)
    localStorage.removeItem('bencao')
    localStorage.sub = (data.sub)
    
    function mudarJSparaPHP(nome, valor, dias){
     // Creating a cookie after the document is ready
  $(document).ready(function () {
      createCookie(nome, valor, dias);
  });
     
  // Function to create the cookie
  function createCookie(name, value, days) {
      var expires;
        
      if (days) {
          var date = new Date();
          date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
          expires = "; expires=" + date.toGMTString();
      }
      else {
          expires = "";
      }
        
      document.cookie = escape(name) + "=" + 
          escape(value) + expires + "; path=/";
    }
  }
   
    mudarJSparaPHP("nome", localStorage.nome, "5")
    mudarJSparaPHP("email",localStorage.email,"5")
    mudarJSparaPHP("sub",localStorage.sub,"5")

}
window.onload = function() {
    google.accounts.id.initialize({
        client_id: "559753341327-9631faub711ui1oqm2mfgh6hp1lbjvrq.apps.googleusercontent.com",
        callback: handleCredentialResponse
        
    });
    google.accounts.id.renderButton(
        document.getElementById("buttonDiv"), {
            theme: "outline",
            size: "large",
            type: "standard",
            shape: "pill",
            text: "$ {button.text}",
            locale: "pt-br",
            logo_aligment: "rigth",
            width: "250"
        } // customization attributes
    );
    //document.getElementById("picture").setAttribute("src" ,data.picture)
    google.accounts.id.prompt(); // also display the One Tap dialog
    
}

</script>

<head>

    <meta charset="utf-8">
    <title>Sub BuS</title>
    <link rel="stylesheet" href="imagem.css">
    <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

    <link href="Imagem.css">
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <link href="Style.css" rel="stylesheet" />
    <script src="https://accounts.google.com/gsi/client" async defer></script>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
    </script>


</head>

<body>

<!--<p id="nome"></p>
<p id="sub"></p>
<p id="email"></p>
<p id="given_name"></p>
<p id="family_name"></p>

<p id="verifiedEmail"></p>
--><img id="imagem" style="display:none"/>


    <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
        <div class="container-fluid">
            <li style="list-style-type: none;"><a class="navbar-brand" href="index.php"
                    style="color: rgb(233, 0, 0); font-size: 32; margin-right: -23%;">SBS</a></li>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position:absolute;">Entrar
            </p>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">



                    <li class="nav-item" style="list-style-type: none;">

                    </li>
                </ul>
                <form class="d-flex" role="search">

                </form>


                <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a
                        href="cadastro.php" style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a></button>
            </div>
        </div>
    </nav>

    <b>
        <div class="dropdown">

            <div class="dropbtn" style="border:none" type="submit">Menu
                <scan id="triangle-right">

                </scan>
            </div>


            <ul class="dropdown-content">
                <!--<li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="linha.html">Linhas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="rotas.html">Rotas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="terminais.html">Terminais<br></a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="ajuda.html">Ajuda</a></li>-->
                <center>
                    <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a
                            href="linha.php" class=letra-menu id="letra-nao-mudar">Linhas</a></li>
                    <li class="divisor-menu" style="list-style-type: none;"></li>
                    <li id="menu-rotas" class="item-menu" style="color: white;list-style-type: none;"><a
                            href="rotas.php" class=letra-menu id="letra-nao-mudar">Rotas</a></li>
                    <li class="divisor-menu" style="list-style-type: none;"></li>
                    <li id="menu-terminais" class="item-menu" style="color: white;list-style-type: none;"><a
                            href="terminais.php" class=letra-menu id="letra-nao-mudar">Terminais</a></li>
                    <li class="divisor-menu" style="list-style-type: none;"></li>
                    <li id="menu-ajuda" class="item-menu" style="color: white;list-style-type: none;"><a
                            href="ajuda.php" class=letra-menu id="letra-nao-mudar">Ajuda</a></li>
                </center>
            </ul>
        </div>
    </b>





    <center>
        <div style="position: absolute;margin-left: 11.9%;"><img src="imagens/TCC_Logo.png" height="450px"
                width="450px " />
            <div style="color: darkred;font-size: 30px;">
                SuB BuS
                <p style="font-size: 20px;">Sistema de rotas urbanas</p>
            </div>
        </div>
        <div style="width: 6px; height: 700px;background-color: black; border-radius: 6px;position: static;"></div>
        <form action="" method="POST">
            <scan class="div-login">

                <p style="color: white; margin-top:5%;font-size: 30px;">Entrar</p>
                <p style="margin-bottom:-5%;color:white" id="divTeste"><?php
  
  include('login_conexao.php');
  
  if(/*isset($_POST['nome']) || */isset($_POST['email']) || isset($_POST['senha'])){
    /*if(strlen($_POST['nome']) == 0){
      echo "Preencha seu nome";
    }*/
    if(strlen($_POST['email']) == 0){
      echo "Preencha seu E-mail";
    }
    else if(strlen($_POST['senha']) == 0){
      echo "Preencha sua senha";
    }
    
    else{
      /*$ct_nome = $mysqli->real_escape_string($_POST['nome']);*/
      
      
      $sql_code = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
      $sql_query = $mysqli->query($sql_code) or die("Falha na execução do código SQL: ". $mysqli->error);

      $quantidade = $sql_query -> num_rows;
      if($quantidade == 1){
          
          
          
          
          echo "Login realizado com sucesso";
      }
      
      else{
          echo "E-mail ou senha estão incorretos";
        
      }
    }
  }
  ?></p>
                <li style="list-style-type: none;color:  white;">E-mail:<input class="campo-texto-pequeno-login"
                        placeholder="Digite aqui" aria-label="Search" style="margin-right:1.5%;margin-top: 8%;"
                        name="email"></li>
                <li style="list-style-type: none;color:  white;">Senha:<input class="campo-texto-pequeno-login"
                        type="password" placeholder="Digite aqui" aria-label="Search"
                        style="margin-right:1.5%;margin-top: 8%;" name="senha"></li>
                <li style="list-style-type: none; margin-left: -35%;margin-top: 5%;"><a href="esqueci_senha.php"
                        style="color: white;">Esqueci minha senha</a></li>
                <button class="botao-login-entrar" type="submit" style="margin-right: 1%;margin-top: 5%;"
                    id="login-entrar"><a href="login.php" style="color: rgb(255, 255, 255); text-decoration: none;"
                        onclick='insereTexto()'><b>Entrar</b></a></button>
                <div
                    style="width: 500px;height:4px;margin-top: 7%;z-index: 1;background-color: white;border-radius: 8px;">
                </div>
                <p style="color: white;font-size:20px;margin-top:6%">Entre também com:</p>
                <div style="list-style-type: none;" id="buttonDiv" onclick=googleMudarPagina()></div>
                
            </scan>
        </form>



        <footer class = "footer-fixo">
            <div class="rodape">
                <li style="list-style-type: none;">

                    
                <li style="list-style-type: none; margin-top: 0%;"><a
                        style="color:white ; text-align: start;position: absolute; margin-left: -46%;"
                        href="sobre.php">Sobre
                        nós</a></li>

                <p style="color: white; font-size: 16 ;">
                    SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso
                    ao
                    transporte público de Londrina
                    <br>
                    2022
                </p>
                </li>
                <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;"
                    href="equipe.php">Equipe de desenvolvedores</a>

            </div>

        </footer>
    </center>
</body>




</html>