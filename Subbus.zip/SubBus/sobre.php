<!DOCTYPE html>
<html lang="pt-br">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sub BuS</title>
  <link rel="stylesheet" href="imagem.css">
  <script scr="https://kit.fontawessome.com/a076d05399.js"></script>

  <link href="Imagem.css">
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
  <link href="Style.css" rel="stylesheet" />

  <!-- JavaScript Bundle with Popper -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8" crossorigin="anonymous">
  </script>


</head>

<body>




  <nav class="navbar navbar-expand-lg bg-light" style="margin-bottom: 0%;">
    <div class="container-fluid">
      <li style="list-style-type: none;"><a class="navbar-brand" href="index.php"
          style="color: red; font-size: 20; margin-right: -23%;">SBS</a></li>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <p class="titulo" style="margin-left: -53%; text-decoration: none;font-size: 20px;position: absolute;">Sobre</p>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">



          <li class="nav-item" style="list-style-type: none;">

          </li>
        </ul>
        <form class="d-flex" role="search">

        </form>

        <button class="botao-login" type="submit" style="margin-right: 1%;" id="login"><a href="login.php"
            style="color: white; text-decoration: none;"><b>Entrar</b></a></button>
        <button class="botao-cadastro" type="submit" style="margin-right: 0%;" id="cadastro"><a href="cadastro.php"
            style="color: white;text-decoration: none;"><b>Cadastrar-se</b></a></button>
      </div>
    </div>
  </nav>

  <b>
    <div class="dropdown">

      <div class="dropbtn" style="border:none" type="submit">Menu
        <scan id="triangle-right">

        </scan>
      </div>


      <ul class="dropdown-content">
        <!--<li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="linha.html">Linhas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="rotas.html">Rotas</a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="terminais.html">Terminais<br></a></li>
          
                <li>
                  <hr class="menu-divider">
                </li>
                <li><a class="menu-item" href="ajuda.html">Ajuda</a></li>-->
        <center>
          <li id="menu-linhas" class="item-menu" style="color: white;list-style-type: none"><a href="linha.php"
              class=letra-menu id="letra-nao-mudar">Linhas</a></li>
          <li class="divisor-menu" style="list-style-type: none;"></li>
          <li id="menu-rotas" class="item-menu" style="color: white;list-style-type: none;"><a href="rotas.php"
              class=letra-menu id="letra-nao-mudar">Rotas</a></li>
          <li class="divisor-menu" style="list-style-type: none;"></li>
          <li id="menu-terminais" class="item-menu" style="color: white;list-style-type: none;"><a href="terminais.php"
              class=letra-menu id="letra-nao-mudar">Terminais</a></li>
          <li class="divisor-menu" style="list-style-type: none;"></li>
          <li id="menu-ajuda" class="item-menu" style="color: white;list-style-type: none;"><a href="ajuda.html"
              class=letra-menu id="letra-nao-mudar">Ajuda</a></li>
        </center>
      </ul>
    </div>
  </b>


  <script src="/Animacao.js"></script>
  <center>
    <img src="imagens/TCC_Logo.png" height="350px" width="350px" style="margin-top:-2.6%;" />
    <div>
      <li style="list-style-type: none;"><p style="font-size: 32px;"><a style="text-decoration:none;color: rgb(187, 0, 0);" href="index.php">SuB BuS</a></p></li>
      <li style="list-style-type: none;"><div class = "borda-sobre"><p style="font-size:20px ;">A Sub Bus é um sistema de gestão de informações sobre as linhas de transporte público de Londrina, e está no mercado desde 2022, sempre atualizando rotas, linhas e horários dos ônibus da cidade metropolitana do norte do Paraná.</p>
        </div></li>
        <li style="list-style-type: none;"><div class = "borda-sobre"><p style="font-size:20px ;">O sistema foi desenvolvido com a ideia vinda de problemas vivenciados por um dos desenvolvedores, assim, o conceito do site junto da criação de nosso TCC, surge o sistema SuB BuS</p>
        </div></li>
    </div>
    
    <div>
        <li style="list-style-type: none;height: 50px;"><div class = "borda-sobre"><p style="font-size:22px ;">E-mail para contato: <a href="#">subbuslondrina@subbus.com</a></p></div></li>
      </div>
      <div>
        <li style="list-style-type: none;"><div class = "borda-sobre"><p style="font-size:22px ;">CNPJ: 12.345.67/9101-11</p></div></li>
      </div>
      <footer class = "footer-fixo">
        <div class="rodape">
      <li style="list-style-type: none;">
          
        <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre nós</a>
        <li style="list-style-type: none; margin-top: 0%;"><a style="color:white ; text-align: start;position: absolute; margin-left: -46%;" href="sobre.html">Sobre nós</a></li>
      
          <p style="color: white; font-size: 10;">
            SuB Bus é um projeto criado com o foco na atividade informativa e com intuito de facilitar o acesso ao
            transporte público de Londrina
            <br>
            2022
          </p>
        </li>
        <a style="color:white ; text-align: start;position: absolute; margin-left: -46%;margin-top: -2%;" href="equipe.php">Equipe de desenvolvedores</a>
          
        </div>
      
      </footer>
  </center>
</body>




</html>